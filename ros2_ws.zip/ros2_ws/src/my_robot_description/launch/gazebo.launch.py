import os

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_path = get_package_share_directory("my_robot_description")

    xacro_file = os.path.join(pkg_path, "urdf", "my_robot.urdf.xacro")

    robot_description = ParameterValue(
        Command(["xacro ", xacro_file]),
        value_type=str
    )

    ros_gz_sim_path = get_package_share_directory("ros_gz_sim")

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ros_gz_sim_path, "launch", "gz_sim.launch.py")
        ),
        launch_arguments={
            "gz_args": "-r /home/muhammad/gazebo_worlds/poles_world.sdf"
        }.items()
    )

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{
            "robot_description": robot_description,
            "use_sim_time": True
        }],
        output="screen"
    )

    spawn_robot = Node(
	package="ros_gz_sim",
        executable="create",
        arguments=[
            "-name", "my_robot",
            "-topic", "robot_description",
            "-x", "0",
            "-y", "0",
            "-z", "0.3"
        ],
        output="screen"
    )
    
    imu_bridge = Node(
	package="ros_gz_bridge",
	executable="parameter_bridge",
	arguments=[
	    "/imu@sensor_msgs/msg/Imu[ignition.msgs.IMU"
	],
	output="screen"
    )

    camera_bridge = Node(
	package="ros_gz_bridge",
	executable="parameter_bridge",
	arguments=[
	    "/image_raw@sensor_msgs/msg/Image[ignition.msgs.Image"
	],
	output="screen"
    )
    
    cmd_vel_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        arguments=[
            "/cmd_vel@geometry_msgs/msg/Twist]ignition.msgs.Twist"
        ],
        output="screen"
    )

    return LaunchDescription([
        gazebo,
        robot_state_publisher,
        imu_bridge,
        camera_bridge,
        cmd_vel_bridge,

        TimerAction(
            period=3.0,
            actions=[spawn_robot]
        )
    ])
